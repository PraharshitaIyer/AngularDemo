import { Component } from "@angular/core";

@Component({
    selector:'two',
    templateUrl:'a.html'
})
export class TwoWay{
name="ajay";

}