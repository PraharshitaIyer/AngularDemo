import { Component } from "@angular/core";

@Component({
    selector:'two',
    templateUrl:'a.html'

})
export class TwoWay{
  moneydata="752.145";
  data="MyString";
  today=new Date();
  jsonobj= {fname: 'Harsha', lname: 'Iyer', nested: {xyz: 3, numbers: [1, 2, 3, 4, 5]}}
 
}
  
