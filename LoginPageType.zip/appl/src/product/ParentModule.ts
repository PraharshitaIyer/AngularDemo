import { NgModule } from "@angular/core";
import { BrowserModule } from '@angular/platform-browser';
import {ParentComponent} from './parent';
import { FormsModule } from '@angular/forms';
import { RegCompoent } from "./Registration";
import { pageComponent } from "./page";
import { ReactiveFormsModule} from '@angular/forms';
@NgModule({
    declarations: [
        ParentComponent,RegCompoent,pageComponent
      ],
      imports: [
        BrowserModule,FormsModule,ReactiveFormsModule
      ],
      bootstrap: [ParentComponent]
    })
export class ParentModule{

}