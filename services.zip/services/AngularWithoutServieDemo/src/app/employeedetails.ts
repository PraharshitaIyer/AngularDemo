import { Component} from '@angular/core';

@Component({
    selector:'empdetail',
    template:`<h3>Employee Details</h3>
    <ul *ngFor="let Emp of Employee">
    <li> {{Emp.id}}.{{Emp.name}}</li>
    </ul>`
})
export class EmployeeDetailComponent {

    public Employee = [
        {"id":1,"name":"Harsha"},
      {"id":2,"name":"Varsha"},
      {"id":3,"name":"Ram"}
    ];
    
}