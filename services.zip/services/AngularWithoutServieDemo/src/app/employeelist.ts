import { Component} from '@angular/core';


@Component({
    selector:'emplist',
    template:`<h3>Employee List</h3>
    <ul *ngFor="let Employee of Employee">
    <li>{{Employee.name}}</li>
    </ul>`
})
export class EmployeeListComponent {
    public Employee = [
        {"id":1,"name":"Harsha"},
      {"id":2,"name":"Varsha"},
      {"id":3,"name":"Ram"}
    ];
 
}