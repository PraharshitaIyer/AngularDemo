import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
    selector:'emplist',
    template:`<h3>Employee List</h3>
    <ul *ngFor="let Employee of Employee">
    <li>{{Employee.name}}</li>
    </ul>`
})
export class EmployeeListComponent implements OnInit{
    public Employee = [];
 constructor( private _employeeservive: EmployeeService){}

 ngOnInit(){
     this.Employee=this._employeeservive.getEmployee();
 }
}