import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {EmployeeService} from './employee.service';
import { AppComponent } from './app.component';
import { from } from 'rxjs';
import { EmployeeDetailComponent } from './employeedetails';
import { EmployeeListComponent } from './employeelist';

@NgModule({
  declarations: [
    AppComponent,EmployeeDetailComponent,EmployeeListComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
