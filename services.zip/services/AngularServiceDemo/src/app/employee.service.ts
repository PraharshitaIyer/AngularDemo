import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor() { }
   
  getEmployee(){
    return [
      {"id":1,"name":"Harsha"},
      {"id":2,"name":"Varsha"},
      {"id":3,"name":"Ram"}
   ];
  }

}
