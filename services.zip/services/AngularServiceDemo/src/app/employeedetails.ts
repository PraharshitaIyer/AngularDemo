import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';
@Component({
    selector:'empdetail',
    template:`<h3>Employee Details</h3>
    <ul *ngFor="let Emp of Employee">
    <li> {{Emp.id}}.{{Emp.name}}</li>
    </ul>`
})
export class EmployeeDetailComponent implements OnInit{

    public Employee = [];
    constructor( private _employeeservive: EmployeeService){}
    ngOnInit(){
        this.Employee=this._employeeservive.getEmployee();
    }
}