import { NgModule } from "@angular/core";
import { BrowserModule } from '@angular/platform-browser';
import {ParentComponent} from './parent';
import { FormsModule } from '@angular/forms';
import { ChildComponent } from "./Child";
@NgModule({
    declarations: [
        ParentComponent,ChildComponent
      ],
      imports: [
        BrowserModule,FormsModule
      ],
      bootstrap: [ParentComponent]
    })
export class ParentModule{

}