import {Component} from'@angular/core';

@Component({
    selector:'parent',
    template:`<br />
            <child [pInp]="parentMsg"></child><br /><br />
            <child (msgToEmit)='display($event)'></child>{{data}}
            `    
})
export class ParentComponent{

parentMsg="Parent Msg";
data="";
display(childmsg){
    this.data=childmsg;
}

}