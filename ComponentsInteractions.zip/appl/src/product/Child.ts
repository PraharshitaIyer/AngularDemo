import { Component, Input, Output, EventEmitter } from "@angular/core";

@Component({
    selector:'child',
    templateUrl:'a.html'

})
export class ChildComponent{
  @Input() pInp=null;
  childmsg="Data from Child";
  @Output() msgToEmit= new EventEmitter<String>();
  SendmsgtoParent(){
    this.msgToEmit.emit(this.childmsg);
  }
}
  
