import { Component } from "@angular/core";

@Component({
    selector:'two',
    templateUrl:'a.html'
})
export class TwoWay{
name=null;
email=null;
pass=null;
city=null;
cntry=null;
//this.name

}